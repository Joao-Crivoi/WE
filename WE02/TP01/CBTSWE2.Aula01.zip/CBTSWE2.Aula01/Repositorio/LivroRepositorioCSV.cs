﻿using CBTSWE2.Aula01.Negocio;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace CBTSWE2.Aula01.Repositorio
{
    public class LivroRepositorioCSV : ILivroRepositorio
    {
        private static readonly string nomeArquivoCSV =
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..\Repositorio\livros.csv");


        public List<Livro> ObterTodos()
        {
            var livros = new List<Livro>();

            if (!File.Exists(nomeArquivoCSV))
                return livros;

            foreach (var linha in File.ReadAllLines(nomeArquivoCSV))
            {
                if (string.IsNullOrWhiteSpace(linha)) continue;
                // ignora cabeçalho (se houver)
                if (linha.StartsWith("Livro;Autores;", StringComparison.OrdinalIgnoreCase)) continue;

                var livro = FromCsv(linha);
                if (livro != null)
                    livros.Add(livro);
            }

            return livros;
        }

        public void Salvar(Livro livro)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(nomeArquivoCSV)!);

            var linha = ToCsv(livro);

            if (!File.Exists(nomeArquivoCSV))
            {
                // opcional: gravar cabeçalho
                File.AppendAllLines(nomeArquivoCSV, new[]
                {
                    "Livro;Autores;Emails;Generos;Preco;Quantidade"
                });
            }

            File.AppendAllLines(nomeArquivoCSV, new[] { linha });
        }

        public void SalvarVarios(IEnumerable<Livro> livros)
        {
            foreach (var l in livros) Salvar(l);
        }

        public void LimparArquivo()
        {
            if (File.Exists(nomeArquivoCSV))
                File.Delete(nomeArquivoCSV);
        }

        // ----------------- helpers -----------------

        private static Livro? FromCsv(string linha)
        {
            var partes = linha.Split(';');
            if (partes.Length < 4) return null;

            string titulo = partes[0].Trim();
            var autores = MontarAutores(
                nomesStr: partes[1],
                emailsStr: partes[2],
                generosStr: partes[3]
            );

            double preco = 0;
            int quantidade = 0;

            if (partes.Length >= 5)
                double.TryParse(partes[4], NumberStyles.Any, CultureInfo.InvariantCulture, out preco);
            if (partes.Length >= 6)
                int.TryParse(partes[5], NumberStyles.Any, CultureInfo.InvariantCulture, out quantidade);

            // Usa o construtor que melhor se aplica
            return partes.Length >= 6
                ? new Livro(titulo, autores, preco, quantidade)
                : new Livro(titulo, autores, preco);
        }

        private static string ToCsv(Livro livro)
        {
            var nomes = string.Join("|", livro.Autores.Select(a => a.Nome));
            var emails = string.Join("|", livro.Autores.Select(a => a.Email));
            var generos = string.Join("|", livro.Autores.Select(a => a.Genero.ToString()));

            // escreve sempre com 6 colunas (preço/qty podem ser 0)
            return string.Join(";", new[]
            {
                livro.Titulo,
                nomes,
                emails,
                generos,
                livro.Preco.ToString("0.00", CultureInfo.InvariantCulture),
                livro.Quantidade.ToString(CultureInfo.InvariantCulture)
            });
        }

        private static Autor[] MontarAutores(string nomesStr, string emailsStr, string generosStr)
        {
            var nomes = SplitPipe(nomesStr);
            var emails = SplitPipe(emailsStr);
            var generos = SplitPipe(generosStr);

            var lista = new List<Autor>();
            for (int i = 0; i < nomes.Length; i++)
            {
                var nome = nomes[i].Trim();
                var email = i < emails.Length ? emails[i].Trim() : string.Empty;

                char genero = '?';
                if (i < generos.Length && !string.IsNullOrWhiteSpace(generos[i]))
                {
                    var g = char.ToUpperInvariant(generos[i].Trim()[0]);
                    genero = (g == 'M' || g == 'F') ? g : '?';
                }

                lista.Add(new Autor(nome, email, genero));
            }
            return lista.ToArray();
        }

        private static string[] SplitPipe(string s) =>
            (s ?? string.Empty).Split('|', StringSplitOptions.None);
    }
}

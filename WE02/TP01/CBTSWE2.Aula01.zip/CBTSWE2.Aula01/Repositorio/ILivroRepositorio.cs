﻿using CBTSWE2.Aula01.Negocio;

namespace CBTSWE2.Aula01.Repositorio
{
    public interface ILivroRepositorio
    {
        List<Livro> ObterTodos();
        void Salvar(Livro livro);
        void SalvarVarios(IEnumerable<Livro> livros);
        void LimparArquivo();
    }
}

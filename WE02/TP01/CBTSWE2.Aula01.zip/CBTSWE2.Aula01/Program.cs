﻿using CBTSWE2.Aula01.Negocio;
using CBTSWE2.Aula01.Repositorio;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Hosting;

class Program
{
    static void Main()
    {
        ILivroRepositorio repo = new LivroRepositorioCSV();

        Console.WriteLine("== LISTA DE LIVROS ==");
        foreach (var l in repo.ObterTodos())
            Console.WriteLine(l);

        Console.WriteLine("\n== ADICIONANDO EXEMPLO ==");
        var autores = new[]
        {
            new Autor("Atilio Almeida Costa", "atilio.beck@email.com", 'M'),
            new Autor("João Victor Crivoi", "joao@email.com", 'F')
        };
        var novo = new Livro("Programação Extrema Explicada", autores, 99.90, 2);
        repo.Salvar(novo);

        Console.WriteLine("\nSalvo. Conteúdo atualizado:");
        foreach (var l in repo.ObterTodos())
            Console.WriteLine(l);

        Console.WriteLine("\nPressione ENTER para iniciar o servidor web...");
        Console.ReadLine();

        // WebHost em .NET 6
        var builder = WebApplication.CreateBuilder();
        var app = builder.Build();

        // Rotas
        app.MapGet("/livro/nome", () => repo.ObterTodos().First().Titulo);
        app.MapGet("/livro/tostring", () => repo.ObterTodos().First().ToString());
        app.MapGet("/livro/autores", () => repo.ObterTodos().First().GetNomesAutores());
        app.MapGet("/livro/apresentar", () =>
        {
            var livro = repo.ObterTodos().Last();
            return new
            {
                livro.Titulo,
                Autores = livro.Autores.Select(a => new { a.Nome, a.Email, a.Genero })
            };
        });

        app.Run();
    }
}

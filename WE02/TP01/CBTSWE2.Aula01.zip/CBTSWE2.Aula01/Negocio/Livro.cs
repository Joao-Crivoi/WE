﻿using System;
using System.Text;

namespace CBTSWE2.Aula01.Negocio
{
    public class Livro
    {
        // Atributos (do diagrama Book)
        public string Titulo { get; private set; }
        public Autor[] Autores { get; private set; }
        public double Preco { get; private set; }
        public int Quantidade { get; private set; } = 0;

        // Construtor com qty padrão
        public Livro(string titulo, Autor[] autores, double preco)
        {
            Titulo = titulo;
            Autores = autores;
            Preco = preco;
        }

        // Construtor com qty informado
        public Livro(string titulo, Autor[] autores, double preco, int quantidade)
        {
            Titulo = titulo;
            Autores = autores;
            Preco = preco;
            Quantidade = quantidade;
        }

        // Retorna nomes dos autores separados por vírgula
        public string GetNomesAutores()
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < Autores.Length; i++)
            {
                sb.Append(Autores[i].Nome);
                if (i < Autores.Length - 1)
                    sb.Append(",");
            }
            return sb.ToString();
        }

        // ToString no formato solicitado
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append($"Book[name={Titulo}, authors={{");

            for (int i = 0; i < Autores.Length; i++)
            {
                sb.Append(Autores[i].ToString());
                if (i < Autores.Length - 1)
                    sb.Append(", ");
            }

            sb.Append($"}} , price={Preco}, qty={Quantidade}]");
            return sb.ToString();
        }
    }
}

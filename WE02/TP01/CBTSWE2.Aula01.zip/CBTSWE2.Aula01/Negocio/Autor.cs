﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CBTSWE2.Aula01.Negocio
{
    public class Autor
    {
        public string Nome { get; set; }
        public string Email { get; set; }

        public char Genero { get; set; }
        public Autor(string nome, string email, char genero)
        {
            Nome = nome;
            Email = email;
            Genero = genero;
        }

        public override string ToString()
        {
            return $"{Nome} ({Email}, {Genero})";
        }
    }
}
